package com.example.lenovo.rodienew.util;

/**
 * Created by ADMIN on 20-02-2017.
 */

public class ipaddress {

 public static String ip="http://10.0.2.2/rodi/";
    //public static String ip="https://patelharsh397.000webhostapp.com/rodi/";

}
