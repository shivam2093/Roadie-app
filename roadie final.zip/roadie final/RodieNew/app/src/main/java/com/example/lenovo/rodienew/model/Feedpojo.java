package com.example.lenovo.rodienew.model;

/**
 * Created by ADMIN on 24-03-2017.
 */

public class Feedpojo {

    String id,name;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
