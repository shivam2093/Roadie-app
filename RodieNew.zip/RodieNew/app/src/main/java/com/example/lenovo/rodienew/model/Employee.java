package com.example.lenovo.rodienew.model;

/**
 * Created by tops on 05/01/2017.
 */

public class Employee {

    private String eid,ename,eemail,eno,econtact,edeptid,edeptname,egendername,typeid,etypename;

    public String getEid() {
        return eid;
    }

    public void setEid(String eid) {
        this.eid = eid;
    }

    public String getEname() {
        return ename;
    }

    public void setEname(String ename) {
        this.ename = ename;
    }

    public String getEemail() {
        return eemail;
    }

    public void setEemail(String eemail) {
        this.eemail = eemail;
    }

    public String getEno() {
        return eno;
    }

    public void setEno(String eno) {
        this.eno = eno;
    }

    public String getEcontact() {
        return econtact;
    }

    public void setEcontact(String econtact) {
        this.econtact = econtact;
    }

    public String getEdeptid() {
        return edeptid;
    }

    public void setEdeptid(String edeptid) {
        this.edeptid = edeptid;
    }

    public String getEdeptname() {
        return edeptname;
    }

    public void setEdeptname(String edeptname) {
        this.edeptname = edeptname;
    }

    public String getEgendername() {
        return egendername;
    }

    public void setEgendername(String egendername) {
        this.egendername = egendername;
    }

    public String getTypeid() {
        return typeid;
    }

    public void setTypeid(String typeid) {
        this.typeid = typeid;
    }

    public String getEtypename() {
        return etypename;
    }

    public void setEtypename(String etypename) {
        this.etypename = etypename;
    }
}
