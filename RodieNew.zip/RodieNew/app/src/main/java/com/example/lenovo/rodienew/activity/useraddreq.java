package com.example.lenovo.rodienew.activity;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.widget.Button;
import android.widget.EditText;

/**
 * Created by lenovo on 10-03-2017.
 */

public class useraddreq extends AppCompatActivity {

    EditText eddiscription,edtocity,edtostate,edtocountry,edtoadd,edfmcity,edfmstate,edfmcountry,edfmadd;
    Button bsubmit,bcancle;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);


    }
}
