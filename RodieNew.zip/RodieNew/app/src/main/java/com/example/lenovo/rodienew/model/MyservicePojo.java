package com.example.lenovo.rodienew.model;

/**
 * Created by ADMIN on 24-03-2017.
 */

public class MyservicePojo {

    String id,uid,disc,tocity,tostate,tocountry,toaddress,fcity,fstate,fcountry,faddress,date,time;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getUid() {
        return uid;
    }

    public void setUid(String uid) {
        this.uid = uid;
    }

    public String getDisc() {
        return disc;
    }

    public void setDisc(String disc) {
        this.disc = disc;
    }

    public String getTocity() {
        return tocity;
    }

    public void setTocity(String tocity) {
        this.tocity = tocity;
    }

    public String getTostate() {
        return tostate;
    }

    public void setTostate(String tostate) {
        this.tostate = tostate;
    }

    public String getTocountry() {
        return tocountry;
    }

    public void setTocountry(String tocountry) {
        this.tocountry = tocountry;
    }

    public String getToaddress() {
        return toaddress;
    }

    public void setToaddress(String toaddress) {
        this.toaddress = toaddress;
    }

    public String getFcity() {
        return fcity;
    }

    public void setFcity(String fcity) {
        this.fcity = fcity;
    }

    public String getFstate() {
        return fstate;
    }

    public void setFstate(String fstate) {
        this.fstate = fstate;
    }

    public String getFcountry() {
        return fcountry;
    }

    public void setFcountry(String fcountry) {
        this.fcountry = fcountry;
    }

    public String getFaddress() {
        return faddress;
    }

    public void setFaddress(String faddress) {
        this.faddress = faddress;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }
}
