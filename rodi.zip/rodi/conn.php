<?php


$conn=mysqli_connect("localhost","root","") or exit("Connection Fail");
mysqli_select_db($conn,"rodi") or exit("Database not Found");



?>